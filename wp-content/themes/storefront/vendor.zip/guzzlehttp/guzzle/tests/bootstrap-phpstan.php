<?php

if (!\defined('IDNA_DEFAULT')) {
    \define('IDNA_DEFAULT', 0);
}

if (!\defined('INTL_IDNA_VARIANT_UTS46')) {
    \define('INTL_IDNA_VARIANT_UTS46', 1);
}
