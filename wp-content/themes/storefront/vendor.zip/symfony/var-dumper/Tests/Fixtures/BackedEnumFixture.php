<?php

namespace Symfony\Component\VarDumper\Tests\Fixtures;

enum BackedEnumFixture: string {
    case Hearts = 'H';
    case Diamonds = 'D';
    case Clubs = 'C';
    case Spades = 'S';
}
