<?php

namespace Symfony\Component\VarDumper\Tests\Fixtures;

class ReflectionUnionTypeFixture
{
    public int|string $a;
}
