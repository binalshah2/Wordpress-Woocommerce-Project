<?php

namespace Symfony\Component\VarDumper\Tests\Fixtures;

enum UnitEnumFixture {
    case Hearts;
    case Diamonds;
    case Clubs;
    case Spades;
}
